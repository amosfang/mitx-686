// DO NOT EDIT

import SwiftUI

@main
struct JalanJalanSingaporeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
