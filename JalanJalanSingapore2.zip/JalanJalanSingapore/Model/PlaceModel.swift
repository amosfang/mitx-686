// DO NOT EDIT

struct Place: Identifiable {
    let id: Int
    let image: String
    let name: String
    let description: String
    let link: String
}
